module.exports = {
  secretOrKey: "cat",
};
